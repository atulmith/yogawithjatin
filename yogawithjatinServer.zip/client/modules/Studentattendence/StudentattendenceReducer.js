// Import Actions
import {  } from './StudentattendenceActions';

// Initial State
const initialState = {};

const StudentattendenceReducer = (state = initialState, action) => {
  switch (action.type) {
    default:
      return state;
  }
};

export default StudentattendenceReducer;
