import React, { Component, PropTypes } from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';

// Import Style
import styles from './Studentattendence.css';

class Studentattendence extends Component {
  render() {
    return (
    );
  }
}

const mapStateToProps = (state) => {
  return {};
};

const mapDispatchToProps = (dispatch) => {
  return {};
};

Studentattendence.propTypes = {
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(Studentattendence);
