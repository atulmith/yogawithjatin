// Import Actions
import {  } from './UserregisterActions';

// Initial State
const initialState = {};

const UserregisterReducer = (state = initialState, action) => {
  switch (action.type) {
    default:
      return state;
  }
};

export default UserregisterReducer;
