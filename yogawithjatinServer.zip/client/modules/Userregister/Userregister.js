import React, { Component, PropTypes } from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';

// Import Style
import styles from './Userregister.css';

class Userregister extends Component {
  render() {
    return (
    );
  }
}

const mapStateToProps = (state) => {
  return {};
};

const mapDispatchToProps = (dispatch) => {
  return {};
};

Userregister.propTypes = {
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(Userregister);
