// Import Actions
import {  } from './StudentbatchdetailsActions';

// Initial State
const initialState = {};

const StudentbatchdetailsReducer = (state = initialState, action) => {
  switch (action.type) {
    default:
      return state;
  }
};

export default StudentbatchdetailsReducer;
