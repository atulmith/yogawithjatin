import React, { Component, PropTypes } from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';

// Import Style
import styles from './Studentbatchdetails.css';

class Studentbatchdetails extends Component {
  render() {
    return (
    );
  }
}

const mapStateToProps = (state) => {
  return {};
};

const mapDispatchToProps = (dispatch) => {
  return {};
};

Studentbatchdetails.propTypes = {
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(Studentbatchdetails);
